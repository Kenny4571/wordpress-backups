<?php
/**
 * Footer
 */
return array(
	'title'      => esc_html__( 'Footer', 'sonshine-fse' ),
	'categories' => array( 'sonshine-fse', 'footer' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}},"color":{"background":"#09111a"},"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}}},"textColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group has-foreground-color has-text-color has-background has-link-color" style="background-color:#09111a;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="padding-top:var(--wp--preset--spacing--70);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--70);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"var:preset|spacing|60","left":"var:preset|spacing|70"}}}} -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground"} -->
<h5 class="wp-block-heading has-foreground-color has-text-color has-link-color" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">About Sonshine</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"spacing":{"margin":{"bottom":"var:preset|spacing|70"}}},"textColor":"foreground"} -->
<p class="has-foreground-color has-text-color has-link-color" style="margin-bottom:var(--wp--preset--spacing--70)">Neque porro quisquam est,qu dolorem ipsum quia dolor sita consectetur, adipisci velit, sed quia non numquam eius mos dolore magnam aliquam qvo lupta orporis suscipi</p>
<!-- /wp:paragraph -->

<!-- wp:social-links {"iconColor":"foreground","iconColorValue":"#ffffff","iconBackgroundColor":"secondary","iconBackgroundColorValue":"#f57e49","style":{"spacing":{"blockGap":{"left":"var:preset|spacing|40"}}},"className":"is-style-default"} -->
<ul class="wp-block-social-links has-icon-color has-icon-background-color is-style-default"><!-- wp:social-link {"url":"#","service":"facebook"} /-->

<!-- wp:social-link {"url":"#","service":"x"} /-->

<!-- wp:social-link {"url":"#","service":"linkedin"} /-->

<!-- wp:social-link {"url":"#","service":"instagram"} /--></ul>
<!-- /wp:social-links --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground"} -->
<h5 class="wp-block-heading has-foreground-color has-text-color has-link-color" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">Quick Links</h5>
<!-- /wp:heading -->

<!-- wp:list {"style":{"spacing":{"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40","top":"0","bottom":"0"}}},"className":"Footer-QuickLinks"} -->
<ul style="padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--40)" class="Footer-QuickLinks"><!-- wp:list-item -->
<li><a href="#">Home</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">About Us</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Services</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Blog</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Gallery</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Contact US</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground"} -->
<h5 class="wp-block-heading has-foreground-color has-text-color has-link-color" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">Ministries</h5>
<!-- /wp:heading -->

<!-- wp:list {"style":{"spacing":{"padding":{"right":"var:preset|spacing|40","left":"var:preset|spacing|40","top":"0","bottom":"0"}}},"className":"Footer-QuickLinks"} -->
<ul style="padding-top:0;padding-right:var(--wp--preset--spacing--40);padding-bottom:0;padding-left:var(--wp--preset--spacing--40)" class="Footer-QuickLinks"><!-- wp:list-item -->
<li><a href="#">Kids</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Students</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Worship</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Women</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Missions</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><a href="#">Life Groups</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:heading {"level":5,"style":{"elements":{"link":{"color":{"text":"var:preset|color|foreground"}}},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}}},"textColor":"foreground"} -->
<h5 class="wp-block-heading has-foreground-color has-text-color has-link-color" style="margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:600">News Letter</h5>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Sign up for our weekly newsletter to stay updated on all news and events at Zegen Church. Email updates on new product Announcements, Gift Ideas, Special Promotions and More.</p>
<!-- /wp:paragraph --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|40","bottom":"var:preset|spacing|40","left":"var:preset|spacing|50","right":"var:preset|spacing|50"}},"color":{"background":"#171f27"}},"layout":{"type":"default"}} -->
<div class="wp-block-group has-background" style="background-color:#171f27;padding-top:var(--wp--preset--spacing--40);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--40);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap","justifyContent":"space-between"}} -->
<div class="wp-block-group"><!-- wp:paragraph -->
<p>Sonshine FSE</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"align":"left"} -->
<p class="has-text-align-left">Design by Grace Themes </p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);