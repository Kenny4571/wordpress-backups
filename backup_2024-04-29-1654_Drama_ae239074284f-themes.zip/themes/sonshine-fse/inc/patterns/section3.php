<?php
/**
 * Church Specialties Sections 3
 */
return array(
	'title'      => esc_html__( 'Church Specialties Sections 3', 'sonshine-fse' ),
	'categories' => array( 'sonshine-fse', 'Church Specialties Sections 3' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"},"blockGap":"0"},"color":{"background":"#f6f1e9"}},"layout":{"type":"default"}} -->
<div class="wp-block-group has-background" style="background-color:#f6f1e9;margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"#240c00"}}},"color":{"text":"#240c00"},"spacing":{"margin":{"bottom":"var:preset|spacing|40"}}}} -->
<h5 class="wp-block-heading has-text-align-center has-text-color has-link-color" style="color:#240c00;margin-bottom:var(--wp--preset--spacing--40)">Church Specialties</h5>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"#240c00"}}},"color":{"text":"#240c00"},"spacing":{"margin":{"bottom":"var:preset|spacing|50"}},"typography":{"fontSize":"38px","lineHeight":"1.2"}}} -->
<h5 class="wp-block-heading has-text-align-center has-text-color has-link-color" style="color:#240c00;margin-bottom:var(--wp--preset--spacing--50);font-size:38px;line-height:1.2">Loving God, Helping Communities and<br>Serving the World</h5>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","style":{"spacing":{"margin":{"bottom":"var:preset|spacing|70"}}}} -->
<p class="has-text-align-center" style="margin-bottom:var(--wp--preset--spacing--70)">Quisque at porttitor magna. Namnisulla, lobortis nosed and pulvinara est. Morbi luctus hesed<br> facilisis ante dignissi eget. Phasell lacus ipsum, cursus etrho.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-top:0;padding-bottom:0"><!-- wp:columns {"style":{"spacing":{"blockGap":{"top":"0","left":"var:preset|spacing|60"},"margin":{"top":"0","bottom":"0"},"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0;padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:column {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"foreground","className":"spbox-church"} -->
<div class="wp-block-column spbox-church has-foreground-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":811,"sizeSlug":"full","linkDestination":"custom","style":{"border":{"radius":"0px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/specialties-img1.jpg" alt="" class="wp-image-811" style="border-radius:0px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"spacing":{"margin":{"bottom":"var:preset|spacing|60","top":"var:preset|spacing|60"}}},"textColor":"body-text","fontFamily":"teko"} -->
<h4 class="wp-block-heading has-text-align-center has-body-text-color has-text-color has-link-color has-teko-font-family" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:700">Christening</h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"foreground","className":"spbox-church"} -->
<div class="wp-block-column spbox-church has-foreground-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":812,"sizeSlug":"full","linkDestination":"custom","style":{"border":{"radius":"0px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/specialties-img2.jpg" alt="" class="wp-image-812" style="border-radius:0px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"spacing":{"margin":{"bottom":"var:preset|spacing|60","top":"var:preset|spacing|60"}}},"textColor":"body-text","fontFamily":"teko"} -->
<h4 class="wp-block-heading has-text-align-center has-body-text-color has-text-color has-link-color has-teko-font-family" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:700">Holiday Service</h4>
<!-- /wp:heading --></div>
<!-- /wp:column -->

<!-- wp:column {"style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"backgroundColor":"foreground","className":"spbox-church"} -->
<div class="wp-block-column spbox-church has-foreground-background-color has-background" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0"><!-- wp:image {"id":813,"sizeSlug":"full","linkDestination":"custom","style":{"border":{"radius":"0px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/specialties-img3.jpg" alt="" class="wp-image-813" style="border-radius:0px"/></figure>
<!-- /wp:image -->

<!-- wp:heading {"textAlign":"center","level":4,"style":{"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"700"},"elements":{"link":{"color":{"text":"var:preset|color|body-text"}}},"spacing":{"margin":{"bottom":"var:preset|spacing|60","top":"var:preset|spacing|60"}}},"textColor":"body-text","fontFamily":"teko"} -->
<h4 class="wp-block-heading has-text-align-center has-body-text-color has-text-color has-link-color has-teko-font-family" style="margin-top:var(--wp--preset--spacing--60);margin-bottom:var(--wp--preset--spacing--60);font-size:24px;font-style:normal;font-weight:700">Funeral Service</h4>
<!-- /wp:heading --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);