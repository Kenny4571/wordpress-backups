<?php
/**
 * Welcome to Our Church Sections 2
 */
return array(
	'title'      => esc_html__( 'Welcome to Our Church Sections 2', 'sonshine-fse' ),
	'categories' => array( 'sonshine-fse', 'Welcome to Our Church Sections 2' ),
	'content'    => '<!-- wp:group {"style":{"spacing":{"padding":{"top":"var:preset|spacing|80","bottom":"var:preset|spacing|80","left":"var:preset|spacing|50","right":"var:preset|spacing|50"},"margin":{"top":"0","bottom":"0"}}},"backgroundColor":"foreground","layout":{"type":"default"}} -->
<div class="wp-block-group has-foreground-background-color has-background" style="margin-top:0;margin-bottom:0;padding-top:var(--wp--preset--spacing--80);padding-right:var(--wp--preset--spacing--50);padding-bottom:var(--wp--preset--spacing--80);padding-left:var(--wp--preset--spacing--50)"><!-- wp:group {"style":{"spacing":{"blockGap":"0","padding":{"left":"0","right":"0"}}},"layout":{"type":"constrained","contentSize":"1170px"}} -->
<div class="wp-block-group" style="padding-right:0;padding-left:0"><!-- wp:columns {"style":{"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<div class="wp-block-columns" style="margin-top:0;margin-bottom:0"><!-- wp:column {"width":"45%","style":{"spacing":{"padding":{"top":"0","bottom":"0","left":"0","right":"0"}}},"className":"churchLeftCol"} -->
<div class="wp-block-column churchLeftCol" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:45%"><!-- wp:image {"id":737,"sizeSlug":"full","linkDestination":"none","style":{"border":{"radius":"15px"}}} -->
<figure class="wp-block-image size-full has-custom-border"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/church-large-image.jpg" alt="" class="wp-image-737" style="border-radius:15px"/></figure>
<!-- /wp:image -->

<!-- wp:group {"style":{"color":{"background":"#130701"},"spacing":{"padding":{"top":"var:preset|spacing|60","bottom":"var:preset|spacing|60","left":"var:preset|spacing|60","right":"var:preset|spacing|60"}}},"className":"church-infoBX","layout":{"type":"constrained"}} -->
<div class="wp-block-group church-infoBX has-background" style="background-color:#130701;padding-top:var(--wp--preset--spacing--60);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--60);padding-left:var(--wp--preset--spacing--60)"><!-- wp:heading {"textAlign":"center","level":3,"style":{"elements":{"link":{"color":{"text":"#ffba00"}}},"color":{"text":"#ffba00"},"typography":{"fontSize":"38px","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"top":"0","bottom":"var:preset|spacing|20"}}}} -->
<h3 class="wp-block-heading has-text-align-center has-text-color has-link-color" style="color:#ffba00;margin-top:0;margin-bottom:var(--wp--preset--spacing--20);font-size:38px;font-style:normal;font-weight:600">Jesus</h3>
<!-- /wp:heading -->

<!-- wp:heading {"textAlign":"center","level":5,"style":{"elements":{"link":{"color":{"text":"#ffba00"}}},"color":{"text":"#ffba00"},"typography":{"fontSize":"24px","fontStyle":"normal","fontWeight":"600","lineHeight":"1.3"},"spacing":{"margin":{"top":"0","bottom":"0"}}}} -->
<h5 class="wp-block-heading has-text-align-center has-text-color has-link-color" style="color:#ffba00;margin-top:0;margin-bottom:0;font-size:24px;font-style:normal;font-weight:600;line-height:1.3">has taught us<br>Patience and Love</h5>
<!-- /wp:heading --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column {"width":"10%"} -->
<div class="wp-block-column" style="flex-basis:10%"></div>
<!-- /wp:column -->

<!-- wp:column {"width":"45%","style":{"spacing":{"blockGap":"0","padding":{"right":"0","left":"0","top":"0","bottom":"0"}}}} -->
<div class="wp-block-column" style="padding-top:0;padding-right:0;padding-bottom:0;padding-left:0;flex-basis:45%"><!-- wp:heading {"level":5,"style":{"typography":{"lineHeight":"1.2","fontStyle":"normal","fontWeight":"600","fontSize":"19px"},"spacing":{"margin":{"bottom":"var:preset|spacing|50"}},"color":{"text":"#240c00"}},"fontFamily":"teko"} -->
<h5 class="wp-block-heading has-text-color has-teko-font-family" style="color:#240c00;margin-bottom:var(--wp--preset--spacing--50);font-size:19px;font-style:normal;font-weight:600;line-height:1.2">Welcome to Our Church</h5>
<!-- /wp:heading -->

<!-- wp:heading {"level":3,"style":{"typography":{"fontSize":"45px","lineHeight":"1.0","fontStyle":"normal","fontWeight":"600"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}},"color":{"text":"#240c00"}},"className":"About-head","fontFamily":"teko"} -->
<h3 class="wp-block-heading About-head has-text-color has-teko-font-family" style="color:#240c00;margin-bottom:var(--wp--preset--spacing--60);font-size:45px;font-style:normal;font-weight:600;line-height:1.0">Discover the Power and Love of God</h3>
<!-- /wp:heading -->

<!-- wp:heading {"level":6,"style":{"typography":{"lineHeight":"1.5","fontStyle":"normal","fontWeight":"600","fontSize":"18px"},"spacing":{"margin":{"bottom":"var:preset|spacing|60"}},"color":{"text":"#240c00"}},"className":"border-left-title","fontFamily":"teko"} -->
<h6 class="wp-block-heading border-left-title has-text-color has-teko-font-family" style="color:#240c00;margin-bottom:var(--wp--preset--spacing--60);font-size:18px;font-style:normal;font-weight:600;line-height:1.5">Placerat mi sem, vel imperdiet nunc bibendeget. Nuncings luctus quam vitae facilisis.</h6>
<!-- /wp:heading -->

<!-- wp:paragraph {"style":{"spacing":{"margin":{"bottom":"var:preset|spacing|50"}}},"textColor":"body-text"} -->
<p class="has-body-text-color has-text-color" style="margin-bottom:var(--wp--preset--spacing--50)">Quisque at porttitor magna. Namnisulla, lobortis nosed and pulvinara est. Morbi luctus hesed facilisis ante dignissi eget. Phasell lacus ipsum, cursus etrho, dapibus et erat. Crasinea dictum tellus sametting neque finibus, nec malesuada telly ornare uctus quam vitae facilisis varius.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|70","bottom":"var:preset|spacing|70"}}},"layout":{"type":"constrained"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--70);margin-bottom:var(--wp--preset--spacing--70)"><!-- wp:columns -->
<div class="wp-block-columns"><!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":776,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-check.jpg" alt="" class="wp-image-776"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#130701"},"elements":{"link":{"color":{"text":"#130701"}}}}} -->
<p class="has-text-color has-link-color" style="color:#130701;font-size:18px;font-style:normal;font-weight:600">Peace of Mind</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":776,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-check.jpg" alt="" class="wp-image-776"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#130701"},"elements":{"link":{"color":{"text":"#130701"}}}}} -->
<p class="has-text-color has-link-color" style="color:#130701;font-size:18px;font-style:normal;font-weight:600">Set for Pastor</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column -->

<!-- wp:column -->
<div class="wp-block-column"><!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":776,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-check.jpg" alt="" class="wp-image-776"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#130701"},"elements":{"link":{"color":{"text":"#130701"}}}}} -->
<p class="has-text-color has-link-color" style="color:#130701;font-size:18px;font-style:normal;font-weight:600">100% Satisfation</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"flex","flexWrap":"nowrap"}} -->
<div class="wp-block-group"><!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:image {"id":776,"sizeSlug":"full","linkDestination":"none"} -->
<figure class="wp-block-image size-full"><img src="'.esc_url(get_template_directory_uri()).'/assets/images/icon-check.jpg" alt="" class="wp-image-776"/></figure>
<!-- /wp:image --></div>
<!-- /wp:group -->

<!-- wp:group {"layout":{"type":"constrained"}} -->
<div class="wp-block-group"><!-- wp:paragraph {"style":{"typography":{"fontSize":"18px","fontStyle":"normal","fontWeight":"600"},"color":{"text":"#130701"},"elements":{"link":{"color":{"text":"#130701"}}}}} -->
<p class="has-text-color has-link-color" style="color:#130701;font-size:18px;font-style:normal;font-weight:600">Lifelong Learning</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group -->

<!-- wp:buttons -->
<div class="wp-block-buttons"><!-- wp:button {"textColor":"foreground","style":{"typography":{"fontSize":"17px","fontStyle":"normal","fontWeight":"400"},"spacing":{"padding":{"left":"var:preset|spacing|60","right":"var:preset|spacing|60","top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}},"color":{"background":"#ec6f39"},"border":{"radius":"0px","width":"0px","style":"none"}},"fontFamily":"teko"} -->
<div class="wp-block-button has-custom-font-size has-teko-font-family" style="font-size:17px;font-style:normal;font-weight:400"><a class="wp-block-button__link has-foreground-color has-text-color has-background wp-element-button" href="#" style="border-style:none;border-width:0px;border-radius:0px;background-color:#ec6f39;padding-top:var(--wp--preset--spacing--30);padding-right:var(--wp--preset--spacing--60);padding-bottom:var(--wp--preset--spacing--30);padding-left:var(--wp--preset--spacing--60)">Read More</a></div>
<!-- /wp:button --></div>
<!-- /wp:buttons --></div>
<!-- /wp:column --></div>
<!-- /wp:columns --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->',
);