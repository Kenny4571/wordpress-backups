=== Sonshine FSE ===
Contributors: gracethemes
Tags:blog, news, portfolio, one-column, two-columns, right-sidebar, block-styles, custom-colors, editor-style, custom-background, custom-menu, featured-images, template-editing, full-site-editing, block-patterns,  threaded-comments, wide-blocks, translation-ready
Requires at least: 5.0
Requires PHP:  5.6
Tested up to: 6.4
License: GNU General Public License version 2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
The Sonshine FSE is one of the best themes for non-profit organizations, church congregations, church charity foundations, denomination, missionary, red cross, religious community, church community, national trust, and other similar websites. This multipurpose theme is also suitable for accountant, accounting, banks, agency, business, corporate, investment, startup, venture capital, construction, hotel, restaurant, flower shop, education, coaching, sports, medical, doctor, gym, fitness, travel and tour website, modelling and wedding. It comes with a highly dynamic and detailed homepage that can be readily used to display information about your business to your audience.  It a Full Site Editing-based theme and comes completely free of cost. As it is a free church charity WordPress theme, you will not need to spend a penny using it. This theme comes with a super user-friendly design and can be seamlessly operated by both mature and newbie users without the need for professional coding skills. This free church charity WordPress theme is compatible with multiple browsing platforms. The theme comes with HD retina-ready display quality, which works with the same efficiency on every device regardless of its resolution without cracking at all. Multiple popular language builder plugins, such as Polylang, Weglot, WPML, etc., are ideally compatible with it. This theme is also compatible with many plugins such as WooCommerce, Contact Form 7, Yoast SEO, WPForms, BuddyPress.

== Theme License & Copyright == 

* Sonshine FSE WordPress Theme, Copyright 2024 Grace Themes 
* Sonshine FSE is distributed under the terms of the GNU GPL

== Changelog ==

= 1.0 =
* Initial version release

= 1.1 =
* fonts not fount issue fixed.



== Resources ==

Theme is Built using the following resource bundles.

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/779576 ( Header Banner image)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/930432  ( section fist column first image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/913784  ( section fist column second image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1249522  ( section fist column third image)


= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1013295  ( welcome section image)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/906427  ( Church Specialties section3 image 1)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1250322  ( Church Specialties section3 image 2)

= Images =
Image for theme screenshot, Copyright pxhere.com
License: CC0 1.0 Universal (CC0 1.0)
Source: https://pxhere.com/en/photo/1357363  ( Church Specialties section3 image 3)


    
For any help you can mail us at support@gracethemes.com