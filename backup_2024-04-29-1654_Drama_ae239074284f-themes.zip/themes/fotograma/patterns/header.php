<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Title: Header
 * Slug: fotograma/header
 * Categories: featured, header
 */
?>

<!-- wp:group {"style":{"spacing":{"blockGap":"0px"}},"layout":{"type":"default"}} -->
<div class="wp-block-group"><!-- wp:site-title {"style":{"spacing":{"margin":{"top":"0px","bottom":"0px","right":"0px","left":"0px"}}}} /--></div>
<!-- /wp:group -->
