<?php declare( strict_types = 1 ); ?>
<?php
/**
 * Title: Search
 * Slug: fotograma/search
 * Inserter: no
 */
?>

<!-- wp:search {"label":"","showLabel":false,"placeholder":"<?php echo esc_html_x( 'Search...', 'This is a placeholder text in a search field', 'fotograma' ); ?>","buttonText":"Search","buttonUseIcon":true} /-->
